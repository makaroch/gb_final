from enum import Enum


class Sorts(Enum):
    popular = "popular"
    rate = "rate"
    price_up = "price_up"
    price_down = "price_down"



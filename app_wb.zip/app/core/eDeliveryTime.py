from enum import Enum


class DeliveryTime(Enum):
    two_days = 52
    three_days = 76
    five_days = 124

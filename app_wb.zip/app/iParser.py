from abc import ABC


class IParser(ABC):
    def get_data(self):
        pass
